import java.util.Scanner;
import java.util.Random;
public class Main
{
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Random generatore = new Random();
        int risposta = 0;
        int[] array = new int[100];
        int Narray = 0;
        int RandomArray=0;
        int casella=0;
        int Valore=0;
        do {

            System.out.println("Scegli una delle seguenti opzioni");
            System.out.println("1- Caricamento da tastiera");
            System.out.println("2- Caricamento random");
            System.out.println("3- Visualizzazione numeri inseriti");
            System.out.println("4- Inserimento in posizione");
            System.out.println("5- Cancellazione di un numero inserito");
            System.out.println("6- Cancellazione di tutti gli elementi");
            risposta = in.nextInt();
            switch (risposta) {
                case 1:
                    System.out.println("Quanti valori dell'array vuoi inserire? (100 max.)");
                    Narray = in.nextInt();
                    if (Narray > 100 && Narray < 0)
                    {
                        System.out.println("Non si possono inserire più di 100 numeri o meno di 1");
                    } else
                    {
                        for (int i = 0; i < Narray; i++)
                        {
                            System.out.println("Inserisci i numeri");
                            array[i] = in.nextInt();
                        }
                    }
                    break;
                case 2:
                    System.out.println("Quanti numeri random vuoi generare?");
                    Narray=in.nextInt();
                        for (int a = 0; a < Narray; a++)
                        {
                            array[a] = generatore.nextInt(50);
                        }
                    break;
                case 3:
                    for (int b = 0; b < Narray; b++)
                        System.out.println(array[b]);
                    break;
                case 4:
                    System.out.println("Quale casella vuoi modificare?");
                    casella=in.nextInt();
                    System.out.println("Che valore vuoi inserire?");
                    array[casella]=in.nextInt();
                case 5:
                case 6:
            }
        }  while (risposta != 0);

    }
}